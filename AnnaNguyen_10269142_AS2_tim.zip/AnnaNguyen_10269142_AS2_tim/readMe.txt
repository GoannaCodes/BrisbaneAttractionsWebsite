Originally, had aria-labels on font awesome icons for location links, but have removed them after validation. 
There are cases like on the hang out category page where a horizontal divider is visible on mobile, but disappears on iPad and desktop. 
All images used that are referenced in the About Page were used without modifying the image. Images not credited were taken in person by me. 